**********
Algorithms
**********

.. automodule:: toponetx.algorithms.eigen_align
    :members:

.. automodule:: toponetx.algorithms.spectrum
    :members: