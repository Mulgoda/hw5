.. _tutorials:

=========
Tutorials
=========

.. nbgallery::
   :maxdepth: 1
   :glob:

   ../notebooks/*
